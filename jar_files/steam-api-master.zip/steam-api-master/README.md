Steam-api
=========

WARNING: Deprecated
-------------
With recent changes in the Steam API things have changed a lot and I do not have the time available to maintain and update the code. Feel free to fork and continue to expand this code. 



Java Steam API
------

How to use: 

StoreFactory.getSteamStore(String cookies)

Where cookies are cookies taken from a logged in browser. Working on the logging in part so you can save-restore your session. 

Development of this API is in conjuncture with a closed source app. The main goal of this API is to be as fast as possible. I'd love to extend the listing item with a method to buy it instantly, but this would make the retrieval slower (most likely not a lot though), while I may only want to buy 1 in 100. 


Continues release
-----------------
Since version 2.0 this project is continuesly released. This process however does not (yet) work for repo1. If you want to use this artifact you will, for now have to install it manually. 
